---
name: Report a bug
about: Something broke!
title: ''
labels: Bug
assignees: ''

---

Replace this: What happened? What were you trying to achieve?

## Environment

Which environment were you using when you encountered the problem?

```bash
$ python -m platform
# TODO: Your output goes here

$ python -c "import PyPDF2;print(PyPDF2.__version__)"
# TODO: Your output goes here
```

## Code + PDF

This is a minimal, complete example that shows the issue:

```python
# TODO: Your code goes here
```

Share here the PDF file(s) that cause the issue. The smaller they are, the
better. Let us know if we may add them to our tests!

## Traceback

This is the complete Traceback I see:

TODO
