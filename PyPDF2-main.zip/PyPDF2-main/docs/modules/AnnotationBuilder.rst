The AnnotationBuilder Class
---------------------------

.. autoclass:: PyPDF2.generic.AnnotationBuilder
    :members:
    :undoc-members:
    :show-inheritance:
