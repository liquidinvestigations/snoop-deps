The Destination Class
---------------------

.. autoclass:: PyPDF2.generic.Destination
    :members:
    :undoc-members:
    :show-inheritance:
