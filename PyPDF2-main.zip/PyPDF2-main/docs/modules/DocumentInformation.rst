The DocumentInformation Class
-----------------------------

.. autoclass:: PyPDF2.DocumentInformation
    :members:
    :undoc-members:
    :show-inheritance:
