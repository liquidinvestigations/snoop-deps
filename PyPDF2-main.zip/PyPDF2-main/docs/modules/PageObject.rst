The PageObject Class
--------------------

.. autoclass:: PyPDF2._page.PageObject
    :members:
    :undoc-members:
    :show-inheritance:
