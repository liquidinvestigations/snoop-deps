The PageRange Class
-------------------

.. autoclass:: PyPDF2.PageRange
    :members:
    :undoc-members:
    :show-inheritance:
