The PdfMerger Class
-------------------

.. autoclass:: PyPDF2.PdfMerger
    :members:
    :undoc-members:
    :show-inheritance:
