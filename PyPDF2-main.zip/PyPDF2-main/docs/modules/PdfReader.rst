The PdfReader Class
-------------------

.. autoclass:: PyPDF2.PdfReader
    :members:
    :undoc-members:
    :show-inheritance:
