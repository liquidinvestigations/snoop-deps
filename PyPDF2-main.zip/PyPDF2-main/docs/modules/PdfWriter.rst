The PdfWriter Class
-------------------

.. autoclass:: PyPDF2.PdfWriter
    :members:
    :undoc-members:
    :show-inheritance:
