The Transformation Class
------------------------

.. autoclass:: PyPDF2.Transformation
    :members:
    :undoc-members:
    :show-inheritance:
