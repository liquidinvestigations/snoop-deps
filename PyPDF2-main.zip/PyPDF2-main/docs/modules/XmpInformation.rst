The XmpInformation Class
-------------------------

.. autoclass:: PyPDF2.xmp.XmpInformation
    :members:
    :undoc-members:
    :show-inheritance:
